package com.anca.arumi

import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PlaylistActivity : AppCompatActivity(), TrackAdapter.OnTrackClickListener {
    private lateinit var recycler: RecyclerView
    private val tracks = ArrayList<Track>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_playlist)
        recycler = findViewById(R.id.recyclerTracks)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = TrackAdapter(tracks, this)
        loadTracks()
    }

    private fun loadTracks() {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val selection = MediaStore.Audio.Media.IS_MUSIC + "!= 0"
        val sort = MediaStore.Audio.Media.TITLE + " ASC"
        contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown"
                val artist = cursor.getString(artistCol) ?: "Unknown"
                val dur = cursor.getLong(durCol)
                val contentUri: Uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                tracks.add(Track(id, title, artist, dur, contentUri.toString()))
            }
            recycler.adapter?.notifyDataSetChanged()
        }
    }

    override fun onTrackClick(track: Track) {
        // Open player with selected track
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra("track_uri", track.uri)
        intent.putExtra("track_title", track.title)
        startActivity(intent)
    }
}

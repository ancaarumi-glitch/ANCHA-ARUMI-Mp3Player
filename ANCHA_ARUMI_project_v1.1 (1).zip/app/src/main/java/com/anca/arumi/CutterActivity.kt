package com.anca.arumi

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity

class CutterActivity : AppCompatActivity() {
    private var trackUri: Uri? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cutter)
        trackUri = intent.getStringExtra("track_uri")?.let { Uri.parse(it) }

        // UI controls (seekbars are placeholders)
        val sbStart = findViewById<SeekBar>(R.id.sbStart)
        val sbEnd = findViewById<SeekBar>(R.id.sbEnd)
        val btnSave = findViewById<Button>(R.id.btnSaveTrim)
        btnSave.setOnClickListener {
            // In real app: use FFmpeg or audio decoding to trim by start/end and save file.
            // We'll show placeholder behavior here.
            btnSave.isEnabled = false
            btnSave.text = "Menyimpan..."
            // TODO: implement trimming using mobile-ffmpeg or server-side processing.
        }
    }
}

package com.anca.arumi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Request runtime permissions (simple)
        requestPermissionsIfNeeded()

        val btnPlay = findViewById<MaterialButton>(R.id.btnPlay)
        btnPlay.setOnClickListener {
            val intent = Intent(this, PlaybackService::class.java)
            intent.action = PlaybackService.ACTION_TOGGLE_PLAY
            ContextCompat.startForegroundService(this, intent)
        }

        val btnRecord = findViewById<MaterialButton>(R.id.btnRecord)
        btnRecord.setOnClickListener {
            val i = Intent(this, RecorderActivity::class.java)
            startActivity(i)
        }
    }

    private fun requestPermissionsIfNeeded() {
        val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val needed = perms.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (needed.isNotEmpty()) {
                requestPermissions(needed.toTypedArray(), 1001)
            }
        }
    }
}

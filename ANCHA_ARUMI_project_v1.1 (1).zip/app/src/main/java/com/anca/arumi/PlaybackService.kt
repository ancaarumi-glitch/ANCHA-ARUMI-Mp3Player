package com.anca.arumi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class PlaybackService : Service() {
    companion object {
        const val CHANNEL_ID = "ANCHA_ARUMI_CH"
        const val ACTION_TOGGLE_PLAY = "action_toggle_play"
    }

    private var player: MediaPlayer? = null
    private var isPlaying = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TOGGLE_PLAY) {
            togglePlay()
        }
        return START_STICKY
    }

    private fun togglePlay() {
        if (isPlaying) {
            player?.pause()
            isPlaying = false
        } else {
            if (player == null) {
                // placeholder: load an audio resource if present
                player = MediaPlayer()
                // In real app: setDataSource from file/uri then prepareAsync
            }
            player?.start()
            isPlaying = true
            val notif = buildNotification(if (isPlaying) "Memutar" else "Dijeda")
            startForeground(1, notif)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ANCHA ARUMI")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "ANCHA ARUMI", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

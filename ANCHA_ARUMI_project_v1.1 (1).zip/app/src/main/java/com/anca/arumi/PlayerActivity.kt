package com.anca.arumi

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class PlayerActivity : AppCompatActivity() {
    private var player: MediaPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        val uri = intent.getStringExtra("track_uri") ?: return
        val title = intent.getStringExtra("track_title") ?: "Track"
        findViewById<TextView>(R.id.playerTitle).text = title
        val btnToggle = findViewById<MaterialButton>(R.id.btnPlayerToggle)
        btnToggle.setOnClickListener {
            togglePlay(uri)
        }
    }

    private fun togglePlay(uriStr: String) {
        if (player == null) {
            player = MediaPlayer.create(this, Uri.parse(uriStr))
            player?.start()
        } else {
            if (player!!.isPlaying) player?.pause() else player?.start()
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

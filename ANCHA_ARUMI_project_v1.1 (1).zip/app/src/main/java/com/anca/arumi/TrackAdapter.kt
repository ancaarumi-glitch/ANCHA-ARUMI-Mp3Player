package com.anca.arumi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TrackAdapter(private val items: List<Track>, private val listener: OnTrackClickListener) : RecyclerView.Adapter<TrackAdapter.VH>() {
    interface OnTrackClickListener { fun onTrackClick(track: Track) }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_track, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = items[position]
        holder.title.text = t.title
        holder.sub.text = t.artist
        holder.itemView.setOnClickListener { listener.onTrackClick(t) }
    }

    override fun getItemCount(): Int = items.size

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.trackTitle)
        val sub: TextView = itemView.findViewById(R.id.trackSub)
    }
}

package com.anca.arumi

import android.media.audiofx.Equalizer
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class EqualizerActivity : AppCompatActivity() {
    private var equalizer: Equalizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_equalizer)

        // Simple skeleton: attach to audio session 0 (global output)
        equalizer = Equalizer(0, 0)
        equalizer?.enabled = true

        val bandCount = equalizer?.numberOfBands ?: 0
        val tvInfo = findViewById<TextView>(R.id.eqInfo)
        tvInfo.text = "Band: $bandCount"

        // For demo: create simple seekbars if bands available
        val containerIds = listOf(R.id.eqBand1, R.id.eqBand2, R.id.eqBand3)
        val minLevel = equalizer?.bandLevelRange?.get(0) ?: 0
        for (i in 0 until bandCount.coerceAtMost(containerIds.size)) {
            val seek = findViewById<SeekBar>(containerIds[i])
            seek.max = (equalizer!!.bandLevelRange[1] - equalizer!!.bandLevelRange[0]).toInt()
            seek.progress = equalizer!!.getBandLevel(i) - minLevel
            seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(p0: SeekBar?, progress: Int, p2: Boolean) {
                    val level = (progress + minLevel).toShort()
                    equalizer?.setBandLevel(i.toShort(), level)
                }
                override fun onStartTrackingTouch(p0: SeekBar?) {}
                override fun onStopTrackingTouch(p0: SeekBar?) {}
            })
        }
    }

    override fun onDestroy() {
        equalizer?.release()
        super.onDestroy()
    }
}

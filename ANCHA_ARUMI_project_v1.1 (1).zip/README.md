# ANCHA ARUMI - Android Studio Project (Scaffold)
Ini adalah kerangka proyek Android (Kotlin) untuk aplikasi **ANCHA ARUMI Mp3 PLAYER**.
Aplikasi ini berisi contoh dasar:
- Pemutar sederhana dengan Service untuk background play
- Perekam suara sederhana
- UI dasar (Bahasa Indonesia)
- README dengan petunjuk membangun APK

## Cara build di PC (Android Studio)
1. Install Android Studio (rekomendasi versi terbaru)
2. Buka folder `ANCHA_ARUMI_project` sebagai Project
3. Sinkronkan Gradle, lalu Build -> Build Bundle(s) / APK(s) -> Build APK(s)
4. File APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`

## Cara build di HP (Termux) - gambaran umum
- Membangun APK langsung di HP lebih rumit dan membutuhkan environment seperti `gradle` dan Android SDK.
- Rekomendasi: gunakan Android Studio di PC, atau gunakan layanan CI/CD (GitHub Actions / Bitrise / App Center) untuk membangun APK.

## Fitur yang perlu dikembangkan lebih lanjut
- Manajemen playlist (scan storage, metadata)
- Equalizer (pakai AudioEffect)
- Tampilan Lirik (parsing LRC)
- Editor potong lagu (library audio processing)
- Fitur "Buat Lagu" berbasis AI (server-side)
- Optimisasi permissions dan storage access (SAF untuk Android 11+)

## Lisensi
Proyek ini diberikan sebagai starting point untuk pengembangan lanjutan. Silakan modifikasi sesuai kebutuhan.

## Update (features added)
- Scan storage & Playlist UI (activity `PlaylistActivity`).
- Player activity for playing selected track.
- Equalizer skeleton (`EqualizerActivity`) using Android's AudioEffect API.
- Cutter activity UI (`CutterActivity`) — placeholder UI. For real trimming, integrate **mobile-ffmpeg** or perform server-side trimming.

## Note on trimming (ringtones)
To implement real audio trimming on-device, consider using `mobile-ffmpeg` (https://github.com/tanersener/mobile-ffmpeg) or call a server-side process that returns the trimmed file. Example ffmpeg command:
```
ffmpeg -i input.mp3 -ss START_SECONDS -to END_SECONDS -c copy output.mp3
```

